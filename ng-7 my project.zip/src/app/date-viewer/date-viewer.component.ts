import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-viewer',
  templateUrl: './date-viewer.component.html',
  styleUrls: ['./date-viewer.component.less']
})
export class DateViewerComponent implements OnInit {

  constructor() { }
  displaytext:string="Ganga"
  ngOnInit() {
  }

}
