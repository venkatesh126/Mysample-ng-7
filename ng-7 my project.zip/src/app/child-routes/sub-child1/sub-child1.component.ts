import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-child1',
  templateUrl: './sub-child1.component.html',
  styleUrls: ['./sub-child1.component.less']
})
export class SubChild1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
