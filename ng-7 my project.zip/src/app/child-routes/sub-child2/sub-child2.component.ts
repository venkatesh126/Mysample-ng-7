import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-child2',
  templateUrl: './sub-child2.component.html',
  styleUrls: ['./sub-child2.component.less']
})
export class SubChild2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
