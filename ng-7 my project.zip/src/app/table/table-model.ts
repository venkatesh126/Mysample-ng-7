export class TableMeta {
    userMeta: any = [
        {
            "name": "FirstName",
            "label": "firstName",
            "pipe": true
        },
        {
            "name": "Email",
            "label": "email",
            "pipe": true
        },
        {
            "name": "Designation",
            "label": "designation",
            "pipe": true
        }, {
            "name": "DOB",
            "label": "dob",
            "pipe": true
        },
        {
            "name": "HomeTown",
            "label": "hometown",
            "pipe": true
        }]
}