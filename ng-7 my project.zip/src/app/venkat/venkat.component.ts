import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-venkat',
  templateUrl: './venkat.component.html',
  styleUrls: ['./venkat.component.less']
})
export class VenkatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
