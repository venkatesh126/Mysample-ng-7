import { TablePipe } from './table.pipe';

describe('TablePipe', () => {
  it('create an instance', () => {
    const pipe = new TablePipe();
    expect(pipe).toBeTruthy();
  });
});
