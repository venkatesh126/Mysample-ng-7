import { FilterTextPipe } from './filter-text.pipe';

describe('FilterTextPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTextPipe();
    expect(pipe).toBeTruthy();
  });
});
